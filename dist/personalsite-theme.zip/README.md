# Casper-ish

Modifications to the default theme for [Ghost](http://github.com/tryghost/ghost/). See live site at [here](https://nparikh.me).


# Copyright & License

Released under the [MIT license](LICENSE).
